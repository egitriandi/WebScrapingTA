package com.egieTA.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebScrapingTaApplicationTests {

	@Test
	void contextLoads() {
	}

}
